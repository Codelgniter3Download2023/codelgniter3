<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-10 18:13:31 --> Config Class Initialized
INFO - 2023-05-10 18:13:31 --> Hooks Class Initialized
DEBUG - 2023-05-10 18:13:31 --> UTF-8 Support Enabled
INFO - 2023-05-10 18:13:31 --> Utf8 Class Initialized
INFO - 2023-05-10 18:13:31 --> URI Class Initialized
DEBUG - 2023-05-10 18:13:31 --> No URI present. Default controller set.
INFO - 2023-05-10 18:13:31 --> Router Class Initialized
INFO - 2023-05-10 18:13:31 --> Output Class Initialized
INFO - 2023-05-10 18:13:31 --> Security Class Initialized
DEBUG - 2023-05-10 18:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-10 18:13:31 --> Input Class Initialized
INFO - 2023-05-10 18:13:31 --> Language Class Initialized
ERROR - 2023-05-10 18:13:31 --> 404 Page Not Found: FriendsController/index
INFO - 2023-05-10 18:13:44 --> Config Class Initialized
INFO - 2023-05-10 18:13:44 --> Hooks Class Initialized
DEBUG - 2023-05-10 18:13:44 --> UTF-8 Support Enabled
INFO - 2023-05-10 18:13:44 --> Utf8 Class Initialized
INFO - 2023-05-10 18:13:44 --> URI Class Initialized
DEBUG - 2023-05-10 18:13:44 --> No URI present. Default controller set.
INFO - 2023-05-10 18:13:44 --> Router Class Initialized
INFO - 2023-05-10 18:13:44 --> Output Class Initialized
INFO - 2023-05-10 18:13:44 --> Security Class Initialized
DEBUG - 2023-05-10 18:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-10 18:13:44 --> Input Class Initialized
INFO - 2023-05-10 18:13:44 --> Language Class Initialized
ERROR - 2023-05-10 18:13:44 --> 404 Page Not Found: FriendsController/index
INFO - 2023-05-10 18:13:50 --> Config Class Initialized
INFO - 2023-05-10 18:13:50 --> Hooks Class Initialized
DEBUG - 2023-05-10 18:13:50 --> UTF-8 Support Enabled
INFO - 2023-05-10 18:13:50 --> Utf8 Class Initialized
INFO - 2023-05-10 18:13:50 --> URI Class Initialized
DEBUG - 2023-05-10 18:13:50 --> No URI present. Default controller set.
INFO - 2023-05-10 18:13:50 --> Router Class Initialized
INFO - 2023-05-10 18:13:50 --> Output Class Initialized
INFO - 2023-05-10 18:13:50 --> Security Class Initialized
DEBUG - 2023-05-10 18:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-10 18:13:50 --> Input Class Initialized
INFO - 2023-05-10 18:13:50 --> Language Class Initialized
ERROR - 2023-05-10 18:13:50 --> 404 Page Not Found: FriendsController/index
INFO - 2023-05-10 18:35:41 --> Config Class Initialized
INFO - 2023-05-10 18:35:41 --> Hooks Class Initialized
DEBUG - 2023-05-10 18:35:41 --> UTF-8 Support Enabled
INFO - 2023-05-10 18:35:41 --> Utf8 Class Initialized
INFO - 2023-05-10 18:35:41 --> URI Class Initialized
DEBUG - 2023-05-10 18:35:41 --> No URI present. Default controller set.
INFO - 2023-05-10 18:35:41 --> Router Class Initialized
INFO - 2023-05-10 18:35:41 --> Output Class Initialized
INFO - 2023-05-10 18:35:41 --> Security Class Initialized
DEBUG - 2023-05-10 18:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-10 18:35:41 --> Input Class Initialized
INFO - 2023-05-10 18:35:41 --> Language Class Initialized
ERROR - 2023-05-10 18:35:41 --> 404 Page Not Found: FriendsController/index
INFO - 2023-05-10 18:37:37 --> Config Class Initialized
INFO - 2023-05-10 18:37:37 --> Hooks Class Initialized
DEBUG - 2023-05-10 18:37:37 --> UTF-8 Support Enabled
INFO - 2023-05-10 18:37:37 --> Utf8 Class Initialized
INFO - 2023-05-10 18:37:37 --> URI Class Initialized
INFO - 2023-05-10 18:37:37 --> Router Class Initialized
INFO - 2023-05-10 18:37:37 --> Output Class Initialized
INFO - 2023-05-10 18:37:37 --> Security Class Initialized
DEBUG - 2023-05-10 18:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-10 18:37:37 --> Input Class Initialized
INFO - 2023-05-10 18:37:37 --> Language Class Initialized
ERROR - 2023-05-10 18:37:37 --> 404 Page Not Found: Welcome/index
INFO - 2023-05-10 18:40:28 --> Config Class Initialized
INFO - 2023-05-10 18:40:28 --> Hooks Class Initialized
DEBUG - 2023-05-10 18:40:28 --> UTF-8 Support Enabled
INFO - 2023-05-10 18:40:28 --> Utf8 Class Initialized
INFO - 2023-05-10 18:40:28 --> URI Class Initialized
INFO - 2023-05-10 18:40:28 --> Router Class Initialized
INFO - 2023-05-10 18:40:28 --> Output Class Initialized
INFO - 2023-05-10 18:40:28 --> Security Class Initialized
DEBUG - 2023-05-10 18:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-10 18:40:28 --> Input Class Initialized
INFO - 2023-05-10 18:40:28 --> Language Class Initialized
ERROR - 2023-05-10 18:40:28 --> 404 Page Not Found: Welcome/index
INFO - 2023-05-10 18:40:31 --> Config Class Initialized
INFO - 2023-05-10 18:40:31 --> Hooks Class Initialized
DEBUG - 2023-05-10 18:40:31 --> UTF-8 Support Enabled
INFO - 2023-05-10 18:40:31 --> Utf8 Class Initialized
INFO - 2023-05-10 18:40:31 --> URI Class Initialized
DEBUG - 2023-05-10 18:40:31 --> No URI present. Default controller set.
INFO - 2023-05-10 18:40:31 --> Router Class Initialized
INFO - 2023-05-10 18:40:31 --> Output Class Initialized
INFO - 2023-05-10 18:40:31 --> Security Class Initialized
DEBUG - 2023-05-10 18:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-10 18:40:31 --> Input Class Initialized
INFO - 2023-05-10 18:40:31 --> Language Class Initialized
ERROR - 2023-05-10 18:40:31 --> 404 Page Not Found: FriendsController/index
INFO - 2023-05-10 18:44:40 --> Config Class Initialized
INFO - 2023-05-10 18:44:40 --> Hooks Class Initialized
DEBUG - 2023-05-10 18:44:40 --> UTF-8 Support Enabled
INFO - 2023-05-10 18:44:40 --> Utf8 Class Initialized
INFO - 2023-05-10 18:44:40 --> URI Class Initialized
DEBUG - 2023-05-10 18:44:40 --> No URI present. Default controller set.
INFO - 2023-05-10 18:44:40 --> Router Class Initialized
INFO - 2023-05-10 18:44:40 --> Output Class Initialized
INFO - 2023-05-10 18:44:40 --> Security Class Initialized
DEBUG - 2023-05-10 18:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-10 18:44:40 --> Input Class Initialized
INFO - 2023-05-10 18:44:40 --> Language Class Initialized
ERROR - 2023-05-10 18:44:40 --> 404 Page Not Found: FriendsController/index
INFO - 2023-05-10 18:44:45 --> Config Class Initialized
INFO - 2023-05-10 18:44:45 --> Hooks Class Initialized
DEBUG - 2023-05-10 18:44:45 --> UTF-8 Support Enabled
INFO - 2023-05-10 18:44:45 --> Utf8 Class Initialized
INFO - 2023-05-10 18:44:45 --> URI Class Initialized
DEBUG - 2023-05-10 18:44:45 --> No URI present. Default controller set.
INFO - 2023-05-10 18:44:45 --> Router Class Initialized
INFO - 2023-05-10 18:44:45 --> Output Class Initialized
INFO - 2023-05-10 18:44:45 --> Security Class Initialized
DEBUG - 2023-05-10 18:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-10 18:44:45 --> Input Class Initialized
INFO - 2023-05-10 18:44:45 --> Language Class Initialized
ERROR - 2023-05-10 18:44:45 --> 404 Page Not Found: FriendsController/index
