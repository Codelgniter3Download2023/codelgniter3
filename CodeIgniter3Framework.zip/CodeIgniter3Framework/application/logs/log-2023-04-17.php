<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-17 13:52:33 --> Config Class Initialized
INFO - 2023-04-17 13:52:33 --> Hooks Class Initialized
DEBUG - 2023-04-17 13:52:33 --> UTF-8 Support Enabled
INFO - 2023-04-17 13:52:33 --> Utf8 Class Initialized
INFO - 2023-04-17 13:52:33 --> URI Class Initialized
DEBUG - 2023-04-17 13:52:33 --> No URI present. Default controller set.
INFO - 2023-04-17 13:52:33 --> Router Class Initialized
INFO - 2023-04-17 13:52:33 --> Output Class Initialized
INFO - 2023-04-17 13:52:33 --> Security Class Initialized
DEBUG - 2023-04-17 13:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 13:52:33 --> Input Class Initialized
INFO - 2023-04-17 13:52:33 --> Language Class Initialized
INFO - 2023-04-17 13:52:33 --> Loader Class Initialized
INFO - 2023-04-17 13:52:33 --> Helper loaded: url_helper
INFO - 2023-04-17 13:52:33 --> Helper loaded: form_helper
INFO - 2023-04-17 13:52:33 --> Helper loaded: text_helper
INFO - 2023-04-17 13:52:33 --> Helper loaded: html_helper
INFO - 2023-04-17 13:52:33 --> Database Driver Class Initialized
INFO - 2023-04-17 13:52:42 --> Config Class Initialized
INFO - 2023-04-17 13:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-17 13:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-17 13:52:42 --> Utf8 Class Initialized
INFO - 2023-04-17 13:52:42 --> URI Class Initialized
DEBUG - 2023-04-17 13:52:42 --> No URI present. Default controller set.
INFO - 2023-04-17 13:52:42 --> Router Class Initialized
INFO - 2023-04-17 13:52:42 --> Output Class Initialized
INFO - 2023-04-17 13:52:42 --> Security Class Initialized
DEBUG - 2023-04-17 13:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 13:52:42 --> Input Class Initialized
INFO - 2023-04-17 13:52:42 --> Language Class Initialized
INFO - 2023-04-17 13:52:42 --> Loader Class Initialized
INFO - 2023-04-17 13:52:42 --> Helper loaded: url_helper
INFO - 2023-04-17 13:52:42 --> Helper loaded: form_helper
INFO - 2023-04-17 13:52:42 --> Helper loaded: text_helper
INFO - 2023-04-17 13:52:42 --> Helper loaded: html_helper
INFO - 2023-04-17 13:52:42 --> Database Driver Class Initialized
ERROR - 2023-04-17 13:52:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Operation timed out /Applications/MAMP/htdocs/uowSocial-master/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-04-17 13:52:43 --> Unable to connect to the database
INFO - 2023-04-17 13:52:43 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-17 13:52:49 --> Config Class Initialized
INFO - 2023-04-17 13:52:49 --> Hooks Class Initialized
DEBUG - 2023-04-17 13:52:49 --> UTF-8 Support Enabled
INFO - 2023-04-17 13:52:49 --> Utf8 Class Initialized
INFO - 2023-04-17 13:52:49 --> URI Class Initialized
DEBUG - 2023-04-17 13:52:49 --> No URI present. Default controller set.
INFO - 2023-04-17 13:52:49 --> Router Class Initialized
INFO - 2023-04-17 13:52:49 --> Output Class Initialized
INFO - 2023-04-17 13:52:49 --> Security Class Initialized
DEBUG - 2023-04-17 13:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 13:52:49 --> Input Class Initialized
INFO - 2023-04-17 13:52:49 --> Language Class Initialized
INFO - 2023-04-17 13:52:49 --> Loader Class Initialized
INFO - 2023-04-17 13:52:49 --> Helper loaded: url_helper
INFO - 2023-04-17 13:52:49 --> Helper loaded: form_helper
INFO - 2023-04-17 13:52:49 --> Helper loaded: text_helper
INFO - 2023-04-17 13:52:49 --> Helper loaded: html_helper
INFO - 2023-04-17 13:52:49 --> Database Driver Class Initialized
ERROR - 2023-04-17 13:52:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Operation timed out /Applications/MAMP/htdocs/uowSocial-master/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-04-17 13:52:52 --> Unable to connect to the database
INFO - 2023-04-17 13:52:52 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-17 13:52:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Operation timed out /Applications/MAMP/htdocs/uowSocial-master/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-04-17 13:52:59 --> Unable to connect to the database
INFO - 2023-04-17 13:52:59 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-17 13:53:51 --> Config Class Initialized
INFO - 2023-04-17 13:53:51 --> Hooks Class Initialized
DEBUG - 2023-04-17 13:53:51 --> UTF-8 Support Enabled
INFO - 2023-04-17 13:53:51 --> Utf8 Class Initialized
INFO - 2023-04-17 13:53:51 --> URI Class Initialized
DEBUG - 2023-04-17 13:53:51 --> No URI present. Default controller set.
INFO - 2023-04-17 13:53:51 --> Router Class Initialized
INFO - 2023-04-17 13:53:51 --> Output Class Initialized
INFO - 2023-04-17 13:53:51 --> Security Class Initialized
DEBUG - 2023-04-17 13:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 13:53:51 --> Input Class Initialized
INFO - 2023-04-17 13:53:51 --> Language Class Initialized
INFO - 2023-04-17 13:53:51 --> Loader Class Initialized
INFO - 2023-04-17 13:53:51 --> Helper loaded: url_helper
INFO - 2023-04-17 13:53:51 --> Helper loaded: form_helper
INFO - 2023-04-17 13:53:51 --> Helper loaded: text_helper
INFO - 2023-04-17 13:53:51 --> Helper loaded: html_helper
INFO - 2023-04-17 13:53:51 --> Database Driver Class Initialized
ERROR - 2023-04-17 13:54:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Operation timed out /Applications/MAMP/htdocs/uowSocial-master/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-04-17 13:54:01 --> Unable to connect to the database
INFO - 2023-04-17 13:54:01 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-17 14:04:41 --> Config Class Initialized
INFO - 2023-04-17 14:04:41 --> Hooks Class Initialized
DEBUG - 2023-04-17 14:04:41 --> UTF-8 Support Enabled
INFO - 2023-04-17 14:04:41 --> Utf8 Class Initialized
INFO - 2023-04-17 14:04:41 --> URI Class Initialized
DEBUG - 2023-04-17 14:04:41 --> No URI present. Default controller set.
INFO - 2023-04-17 14:04:41 --> Router Class Initialized
INFO - 2023-04-17 14:04:41 --> Output Class Initialized
INFO - 2023-04-17 14:04:41 --> Security Class Initialized
DEBUG - 2023-04-17 14:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-17 14:04:41 --> Input Class Initialized
INFO - 2023-04-17 14:04:41 --> Language Class Initialized
INFO - 2023-04-17 14:04:41 --> Loader Class Initialized
INFO - 2023-04-17 14:04:41 --> Helper loaded: url_helper
INFO - 2023-04-17 14:04:41 --> Helper loaded: form_helper
INFO - 2023-04-17 14:04:41 --> Helper loaded: text_helper
INFO - 2023-04-17 14:04:41 --> Helper loaded: html_helper
INFO - 2023-04-17 14:04:41 --> Database Driver Class Initialized
ERROR - 2023-04-17 14:04:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Operation timed out /Applications/MAMP/htdocs/uowSocial-master/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-04-17 14:04:51 --> Unable to connect to the database
INFO - 2023-04-17 14:04:51 --> Language file loaded: language/english/db_lang.php
